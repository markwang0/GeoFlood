This training material has been developed as material for a graduate course, CE397 Spatial Hydrology, that I taught at the University of Texas at Austin in Fall 2019. The material includes the labs and is distributed with the code in the hope it might be helpful to those users interested in learning GeoFlood and using it for their own applications. Lectures and input data can be downloaded from my group's website https://sites.google.com/site/passalacquagroup/tools-and-data. 

The labs mostly follow and use the Windows installation of the code. Users on Mac or Linux can contact me directly as I have some helpful material collected from my students on Mac and Linux on how to install the code and troubleshoot several errors. 

paola@austin.utexas.edu
